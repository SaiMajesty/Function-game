let firstNumberElement = document.getElementById("firstNumber");

let userInputElement = document.getElementById("userInput");
let gameResultElement = document.getElementById("gameResult");

let gameFailure = "Please Try Again!";
let gameSuccess = "Congratulations! You got it right.";

function restartGame() {
    gameResultElement.textContent = "";
    userInputElement.value = "";
    firstNumberElement.value = "";

}
restartGame();

function Back() {
    window.location.href = ("https://loginpageone.ccbp.tech/");
}

function checkGame() {
    function zero(n) {
        return Math.floor(eval(convertString(n, 0)))
    }
    //eval is keyword in js for evaluation ,it takes up the string and evaluates the expression.
    function one(n) {
        return Math.floor(eval(convertString(n, 1)))
    }

    function two(n) {
        return Math.floor(eval(convertString(n, 2)))
    }

    function three(n) {
        return Math.floor(eval(convertString(n, 3)))
    }

    function four(n) {
        return Math.floor(eval(convertString(n, 4)))
    }

    function five(n) {
        return Math.floor(eval(convertString(n, 5)))
    }

    function six(n) {
        return Math.floor(eval(convertString(n, 6)))
    }

    function seven(n) {
        return Math.floor(eval(convertString(n, 7)))
    }

    function eight(n) {
        return Math.floor(eval(convertString(n, 8)))
    }

    function nine(n) {
        return Math.floor(eval(convertString(n, 9)))
    }

    function plus(n) {
        return `+${n}`
    }

    function minus(n) {
        return `-${n}`
    }

    function times(n) {
        return `*${n}`
    }

    function divided_by(n) {
        return `/${n}`
    }
    //if n is undefined it is the second operand just return itself
    //if n is not undefined it is concatenated with operator which is passed.
    function convertString(n, val) {
        var str = n == undefined ? val : str = val + n;
        return str;
    }

    var text = firstNumberElement.value;
    try {
        eval(text);
        gameResultElement.textContent = gameSuccess;
        gameResultElement.style.backgroundColor = "#028a0f";
    } catch (error) {
        gameResultElement.textContent = gameFailure;
        gameResultElement.style.backgroundColor = "#1e217c";
    }
    userInputElement.value = eval(text);
    gameResultElement.textContent = "";

}